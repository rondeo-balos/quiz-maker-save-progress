=== Quiz Maker ===
Contributors: rondeo-balos
Donate link: 
Tags:  quiz maker, exam, quiz, test, questionnaire, save progress
Requires at least: 4.0
Tested up to: 0.2.1
Stable tag: 0.2.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html

A plugin that Saves AYS Quiz Maker Progress

== Description ==

# A plugin that Saves AYS Quiz Maker Progress

patch notes v1.0.1
 1. Added List of Saves shortcode
 2. Fixed Known issues
 3. Fixed Save and Resume actions and executions

patch notes v0.1.1
 1. Added Save Later Button on quizes with shortcode
 2. Added Resume Feature on quizes
 3. Added a list of saved quizes but not yet implemented properly