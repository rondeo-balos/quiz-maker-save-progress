<?php

define('QMRB_TABLE_NAME', 'quiz_maker_saved_progress');